2013aug12  Paper_led fabrication instructions
   ADC16x250-8 coax rev 2 compatible front panel LED board

Project: Paper_led
Description: front panel power and reset switches with 3 LEDs

6 of these boards have been grouped together onto 1 panel
to align with the PCB fabrication vendor's default PCB panel size.

Design contact :
  Calvin Cheng
  kacweng@berkeley.edu
  University of California - Berkeley
  Radio Astronomy Lab
  B-20 Hearst Field Annex
  Berkeley, CA 94720-3411
  voice: 510 642 5555
  FAX:   510 642 3411

Alternative design contact
  Matt Dexter
  mdexter@berkeley.edu
  voice: 510 643 0381

Purchasing contact : TBD

First purchase order :
  Sunstone 
  http://www.sunstone.com/QuoteQT.aspx
  2013may05
  Q2/E2 2 layers w/ silkscreen and soldermask

Board Size: 2.7960 x 2.7850 inches  (for 6 individual boards)
Panel Size: 3.0 x 3.0 inches (or anything over the board size shown above)
thickness:  0.062"
minimum line width : 0.006" 
minimum spacing   0.006" 
Finished copper:  1.0 oz
surface finish:  Tin Lead
gold fingers: none
slots or cutouts: none

film set definition:   see below.

Board material (laminate): FR4
Impedance control: none
solder mask : LPI  green

silk screen (legend) color:
  top: white 
  bottom: none.


all hole diameters are after plating.
minimum hole size : 0.010"
minimum annular ring : 0.006"
hole count: 258

unless otherwise notes all dimensions are in inches.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
Stackup

layer description    thickness   file

      top silk screen            Paper_led_panelized.GTO
      top solder mask            Paper_led_panelized.GTS

1     top             0.0007"    Paper_led_panelized.GTL

      dielectric      0.062"  

2     bottom          0.0007     Paper_led_panelized.GBL

      bottom solder mask         Paper_led_panelized.GBS
      bottom silk screen         Paper_led_panelized.GBO

drill table                      Paper_led_panelized.DRR
drill file                       Paper_led_panelized.DRL
old style text drill file        Paper_led_panelized.TXT
aperture file                    Paper_led_panelized.apr

text description                 this file: gerber_readme.txt
