2013aug12  Paper_led fabrication instructions
   ADC16x250-8 coax rev 2 compatible front panel LED board

Project: Paper_led
Description: front panel power and reset switches with 3 LEDs

1 and only 1 board.
Please see the panelized zip and gerber files for 1 "board"
with 6 of these boards have been grouped together onto 1 panel
to align with the PCB fabrication vendor's default panel size.
That is what was initially purchased.

Design contact :
  Calvin Cheng
  kacweng@berkeley.edu
  University of California - Berkeley
  Radio Astronomy Lab
  B-20 Hearst Field Annex
  Berkeley, CA 94720-3411
  voice: 510 642 5555
  FAX:   510 642 3411

Alternative design contact
  Matt Dexter
  mdexter@berkeley.edu
  voice: 510 643 0381

Purchasing contact : TBD

First purchase order :
  Sunstone 
  http://www.sunstone.com/QuoteQT.aspx
  2013may05
  Q2/E2 2 layers w/ silkscreen and soldermask

Board Size: 1.383.0 x .907 inches  (for 1 individual boards)
thickness:  0.062"
minimum line width : 0.006" 
minimum spacing   0.006" 
Finished copper:  1.0 oz
surface finish:  Tin Lead
gold fingers: none
slots or cutouts: none

film set definition:   see below.

Board material (laminate): FR4
Impedance control: none
solder mask : LPI  green

silk screen (legend) color:
  top: white 
  bottom: none.


all hole diameters are after plating.
minimum hole size : 0.010"
minimum annular ring : 0.006"
hole count: 43

unless otherwise notes all dimensions are in inches.

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
Stackup

layer description    thickness   file

      top silk screen            Paper_led.GTO
      top solder mask            Paper_led.GTS

1     top             0.0007"    Paper_led.GTL

      dielectric      0.062"  

2     bottom          0.0007     Paper_led.GBL

      bottom solder mask         Paper_led.GBS
      bottom silk screen         Paper_led.GBO

drill table                      Paper_led.DRR
drill file                       Paper_led.DRL
old style text drill file        Paper_led.TXT
aperture file                    Paper_led.apr

text description                 this file: gerber_readme.txt
